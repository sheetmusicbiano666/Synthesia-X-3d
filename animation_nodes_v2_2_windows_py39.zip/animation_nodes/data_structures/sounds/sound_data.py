class SoundData:
    def __init__(self, samples, sampleRate):
        self.samples = samples
        self.sampleRate = sampleRate
